package calculadora;

import javafx.fxml.FXML;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;

public class ImcController {
	
	@FXML TextField inputNome;
	@FXML TextField inputPeso;
	@FXML TextField inputAltura;
	@FXML RadioButton setMasculino;
	@FXML RadioButton setFeminino;
	@FXML TextArea outputResultado;
	

	@FXML
	public void Calcular() {
		double peso = Double.parseDouble(inputPeso.getText());
		double altura = Double.parseDouble(inputAltura.getText());
		double imc = peso / (altura*altura);
		outputResultado.setText("Nome: " + inputNome.getText() + "\n"
							  + "IMC: " + imc);
	}
	
	@FXML
	public void Limpar() {
		inputNome.setText("");
		inputPeso.setText("");
		inputAltura.setText("");
		setMasculino.setSelected(false);
		setFeminino.setSelected(false);
		outputResultado.setText("");
	}	
	
}
