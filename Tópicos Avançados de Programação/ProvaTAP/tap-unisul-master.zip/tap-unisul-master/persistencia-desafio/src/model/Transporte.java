package model;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class Transporte {
	
	private StringProperty transporte = new SimpleStringProperty("");
	private StringProperty distancia = new SimpleStringProperty("");
	private StringProperty custo = new SimpleStringProperty("");
	
	
	public final StringProperty transporteProperty() {
		return this.transporte;
	}
	public final String getTransporte() {
		return this.transporteProperty().get();
	}
	public final void setTransporte(final String transporte) {
		this.transporteProperty().set(transporte);
	}
	public final StringProperty distanciaProperty() {
		return this.distancia;
	}
	
	public final String getDistancia() {
		return this.distanciaProperty().get();
	}
	
	public final void setDistancia(final String distancia) {
		this.distanciaProperty().set(distancia);
	}
	
	public final StringProperty custoProperty() {
		return this.custo;
	}
	
	public final String getCusto() {
		return this.custoProperty().get();
	}
	
	public final void setCusto(final String custo) {
		this.custoProperty().set(custo);
	}
	
	

	

		
}
