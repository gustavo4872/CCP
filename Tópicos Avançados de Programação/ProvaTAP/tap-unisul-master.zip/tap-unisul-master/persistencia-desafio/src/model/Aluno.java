package model;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class Aluno {

	private StringProperty nome = new SimpleStringProperty("");
	private StringProperty curso = new SimpleStringProperty("");
	private StringProperty semestre = new SimpleStringProperty("");
	
	
	public final StringProperty nomeProperty() {
		return this.nome;
	}
	public final String getNome() {
		return this.nomeProperty().get();
	}
	public final void setNome(final String nome) {
		this.nomeProperty().set(nome);
	}
	
	public final StringProperty cursoProperty() {
		return this.curso;
	}
	public final String getCurso() {
		return this.cursoProperty().get();
	}
	public final void setCurso(final String curso) {
		this.cursoProperty().set(curso);
	}
	
	public final StringProperty semestreProperty() {
		return this.semestre;
	}
	public final String getSemestre() {
		return this.semestreProperty().get();
	}
	public final void setSemestre(final String semestre) {
		this.semestreProperty().set(semestre);
	}
	
}
