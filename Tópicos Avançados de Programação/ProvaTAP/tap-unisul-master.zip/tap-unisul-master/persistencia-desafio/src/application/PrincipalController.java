package application;

import model.Aluno;
import model.Transporte;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.List;

import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;

public class PrincipalController {

	@FXML TableView<Aluno> tabelaAluno;
	@FXML TableColumn<Aluno, String> colunaNome;
	@FXML TableColumn<Aluno, String> colunaCurso;
	@FXML TableColumn<Aluno, String> colunaSemestre;
	
	@FXML TableView<Transporte> tabelaTransporte;
	@FXML TableColumn<Transporte, String> colunaTransporte;
	@FXML TableColumn<Transporte, String> colunaDistancia;
	@FXML TableColumn<Transporte, String> colunaCusto;
	
	private List<Aluno> alunos = new ArrayList<>();
	private List<Transporte> transportes = new ArrayList<>();
	
	
	@FXML
	public void initialize() {
		converteTextoTransporte();
		converteTextoAluno();
		iniciaTabelaAlunos();
		iniciaTabelaTransportes();
		reloadTableView();
	}
	
	public void iniciaTabelaAlunos() {
		colunaNome.setCellValueFactory(cellData -> cellData.getValue().nomeProperty());
		colunaCurso.setCellValueFactory(cellData -> cellData.getValue().cursoProperty());
		colunaSemestre.setCellValueFactory(cellData -> cellData.getValue().semestreProperty());
	}
	
	public void iniciaTabelaTransportes() {
		colunaTransporte.setCellValueFactory(cellData -> cellData.getValue().transporteProperty());
		colunaDistancia.setCellValueFactory(cellData -> cellData.getValue().distanciaProperty());
		colunaCusto.setCellValueFactory(cellData -> cellData.getValue().custoProperty());
	}
	
	public void converteTextoAluno() {
		alunos.clear();
		try {
			FileReader filer = new FileReader("alunos.txt");
			BufferedReader buffr = new BufferedReader(filer);
			String linha = "";
			while ((linha = buffr.readLine())!=null) {
				String[] dados = linha.split(";");
				Aluno obj = new Aluno();
				obj.setNome(dados[0]);
				obj.setCurso(dados[1]);
				obj.setSemestre(dados[2]);
				alunos.add(obj);
			}
			filer.close();
			buffr.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void converteTextoTransporte() {
		transportes.clear();
		try {
			FileReader filer = new FileReader("transportes.txt");
			BufferedReader buffr = new BufferedReader(filer);
			String linha = "";
			while ((linha = buffr.readLine())!=null) {
				String[] dados = linha.split(";");
				Transporte obj = new Transporte();
				obj.setTransporte(dados[0]);
				obj.setDistancia((dados[1]));
				obj.setCusto((dados[2]));
				transportes.add(obj);
			}
			filer.close();
			buffr.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void reloadTableView() {
		converteTextoAluno();
		converteTextoAluno();
		tabelaAluno.setItems(FXCollections.observableArrayList(alunos));
		tabelaTransporte.setItems(FXCollections.observableArrayList(transportes));	
	}
}
