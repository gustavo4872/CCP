package application;

import java.io.BufferedWriter;
import java.io.FileWriter;

import javafx.fxml.FXML;
import javafx.scene.control.TextField;
import model.Transporte;

public class CadastroTransporteController {
	
	@FXML TextField transporte;
	@FXML TextField distancia;
	@FXML TextField custo;
	
	@FXML
	public void CadastrarTransporte() {
		
		try {
			
			Transporte obj = new Transporte();
			obj.setTransporte(transporte.getText());
			obj.setDistancia(distancia.getText());
//			obj.setCusto(custo.getText());
			
			FileWriter filew = new FileWriter("transportes.txt",true);
			BufferedWriter bufferedw = new BufferedWriter(filew);
			
			bufferedw.append(obj.getTransporte() + ";"
						+    obj.getDistancia() + ";");	
//						+    obj.getCusto() + ";\n" 		
			bufferedw.close();	
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
