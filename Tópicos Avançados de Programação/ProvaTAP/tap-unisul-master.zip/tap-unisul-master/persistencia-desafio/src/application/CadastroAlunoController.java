package application;

import java.io.BufferedWriter;
import java.io.FileWriter;


import javafx.fxml.FXML;
import javafx.scene.control.TextField;
import model.Aluno;

public class CadastroAlunoController {

	@FXML TextField nome;
	@FXML TextField curso;
	@FXML TextField semestre;
	
	@FXML
	public void CadastrarAluno() {
		
		try {
			Aluno obj = new Aluno();
			obj.setNome(nome.getText());
			obj.setCurso(semestre.getText());
			obj.setSemestre(semestre.getText());
			
			FileWriter filew = new FileWriter("alunos.txt",true);
			BufferedWriter bufferedw = new BufferedWriter(filew);
			
			bufferedw.append(obj.getNome() + ";"
						+    obj.getCurso() + ";"
						+    obj.getSemestre() + ";\n");			
			bufferedw.close();	
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
}
