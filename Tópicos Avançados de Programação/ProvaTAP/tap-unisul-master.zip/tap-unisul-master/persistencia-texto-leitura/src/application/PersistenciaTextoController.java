package application;

import java.io.File;
import java.util.ArrayList;

import domain.DadosFile;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.stage.DirectoryChooser;

public class PersistenciaTextoController {
	
	@FXML private TextField local;
	
	@FXML TableView<DadosFile> tabela;
	@FXML TableColumn<DadosFile,String> colunaNome;
	@FXML TableColumn<DadosFile,String> colunaTamanho;
	
	private ArrayList<DadosFile> lista = new ArrayList<DadosFile>();
	
	
	@FXML
	public void initialize() {
		inicializaTabela();
	}
	
	@FXML
	public void buscaDiretorio() {
	
		DirectoryChooser directoryChooser = new DirectoryChooser();
		File selecionado = directoryChooser.showDialog(null);
		
		if(selecionado != null) {
			local.setText(selecionado.getAbsolutePath());
		}
		
	}
	
	@FXML
	public void listar() {
		
		if (!local.getText().equals("")) {
			File diretorio = new File(local.getText());
			
			if (diretorio.isDirectory()) {
				lista.clear();
				File[] vetorTemporario = diretorio.listFiles();  
				
				for (File loop : vetorTemporario) {
					DadosFile obj = new DadosFile();
					obj.setNome(loop.getName());
					obj.settamanho(loop.length() + " Bytes");
					obj.setPath(loop.getAbsolutePath());   
					lista.add(obj);
				}
				
				tabela.setItems(FXCollections.observableArrayList(lista));
			}
		}
	}
	
	@FXML                                                          
	public void apagaLinhaSelecionada() {
		
		DadosFile dadosFile = tabela.getSelectionModel().getSelectedItem(); 
		
		if(dadosFile != null) {   
			File file = new File(dadosFile.getPath());                       
			file.delete();                                            
			lista.remove(dadosFile);                                      
			tabela.setItems(FXCollections.observableArrayList(lista));	
		}
		
	}
	
	@FXML                                                      
	public void apagaTodos() {
		
		for (DadosFile dadosFile : tabela.getItems()) {                  
			File file = new File(dadosFile.getPath());                   
			file.delete();                                        
		}      
		
		lista.clear();                                         
		tabela.setItems(FXCollections.observableArrayList(lista));
		
	}                                                          
	
	private void inicializaTabela() {
		
		colunaNome.setCellValueFactory(cellData -> cellData.getValue().nomeProperty());
		colunaTamanho.setCellValueFactory(cellData -> cellData.getValue().tamanhoProperty());
		
	}
}
