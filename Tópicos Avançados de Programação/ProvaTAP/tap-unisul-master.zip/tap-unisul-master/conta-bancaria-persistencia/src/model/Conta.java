package model;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class Conta {

	private StringProperty nome = new SimpleStringProperty("");
	private StringProperty agencia = new SimpleStringProperty("");
	private StringProperty conta = new SimpleStringProperty("");
	private StringProperty cidade = new SimpleStringProperty("");
	private StringProperty path = new SimpleStringProperty("");
	
	
	public final StringProperty nomeProperty() {
		return this.nome;
	}
	public final String getNome() {
		return this.nomeProperty().get();
	}
	public final void setNome(final String nome) {
		this.nomeProperty().set(nome);
	}
	
	
	public final StringProperty agenciaProperty() {
		return this.agencia;
	}
	public final String getAgencia() {
		return this.agenciaProperty().get();
	}
	public final void setAgencia(final String agencia) {
		this.agenciaProperty().set(agencia);
	}
	
	
	public final StringProperty contaProperty() {
		return this.conta;
	}
	public final String getConta() {
		return this.contaProperty().get();
	}
	public final void setConta(final String conta) {
		this.contaProperty().set(conta);
	}
	
	
	public final StringProperty cidadeProperty() {
		return this.cidade;
	}
	public final String getCidade() {
		return this.cidadeProperty().get();
	}
	public final void setCidade(final String cidade) {
		this.cidadeProperty().set(cidade);
	}
	
	
	public final StringProperty pathProperty() {
		return this.path;
	}
	public final String getPath() {
		return this.pathProperty().get();
	}
	public final void setPath(final String path) {
		this.pathProperty().set(path);
	}
	
}
