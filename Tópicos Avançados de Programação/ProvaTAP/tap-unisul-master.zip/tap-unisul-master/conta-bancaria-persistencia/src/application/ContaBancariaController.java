package application;

import java.io.BufferedWriter;
import java.io.FileWriter;

import javafx.fxml.FXML;
import javafx.scene.control.TextField;
import model.Conta;

public class ContaBancariaController {
		
	@FXML TextField nome;
	@FXML TextField agencia;
	@FXML TextField conta;
	@FXML TextField cidade;
	
	@FXML
	public void cadastrar() {
		
		try {
			Conta a = new Conta();
			
			a.setNome(formataString(nome.getText(), 5));
			a.setAgencia(formataString(agencia.getText(), 5));
			a.setConta(formataString(conta.getText(), 5));
			a.setCidade(formataString(conta.getText(), 5));
		
			FileWriter fw = new FileWriter("contas.txt",true);
			BufferedWriter bw = new BufferedWriter(fw);
			bw.append(a.getNome() +" "+ a.getAgencia() + a.getConta() + a.getCidade() + "\n");
			bw.close();
			fw.close();
			nome.setText("");
			agencia.setText("");
			conta.setText("");
			cidade.setText("");
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	public String formataString(String texto, Integer indice) {
		Integer espacos = 0;
		if (texto.length() > indice) {
			 texto = texto.substring(0, indice);
			 return texto;
		}
		if (texto.length() < indice) {
			espacos = indice - texto.length();
			texto = String.format("%020d", texto);
			return texto;
		}
		return texto;
	}
	
}
