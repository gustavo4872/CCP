package view;

import java.io.File;
import java.util.ArrayList;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.stage.DirectoryChooser;
import model.DadosFile;

public class HomeController {
	
	@FXML TextField txtPath;
	@FXML TableView<DadosFile> tbl;
	@FXML TableColumn<DadosFile, String> colNome;
	@FXML TableColumn<DadosFile, Number> coltamanho;
	
	private ArrayList<DadosFile> lista = new ArrayList<DadosFile>();
	
	@FXML
	public void initialize() {
		iniciaTabela();
	}

//	@FXML
//	public void editarLinhaSelecionada() {
//		try{
//			FileWriter fw = new FileWriter(tbl.getSelectionModel().getSelectedItem().getNome(), true);
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//	}
	
	@FXML
	public void apagaLinhaSelecionada() {
		DadosFile df = tbl.getSelectionModel().getSelectedItem();
		if(df != null) {
			File f = new File(df.getPath());
			f.delete();
			lista.remove(df);
			tbl.setItems(FXCollections.observableArrayList(lista));
		}
	}
	
	@FXML
	public void apagaTudo() {
		for (DadosFile df : tbl.getItems()) {
			File f = new File(df.getPath());
			f.delete();
		}
		lista.clear();
		tbl.setItems(FXCollections.observableArrayList(lista));
	}
	
	@FXML
	public void listar() {
		if(!txtPath.getText().equals("")) {
			File diretorio = new File(txtPath.getText());
			if(diretorio.isDirectory()) {
				lista.clear();
				File[] v = diretorio.listFiles();
				for (File file : v) {
					DadosFile d = new DadosFile();
					d.setNome(file.getName());
					d.setTamanho((int) file.length());
					d.setPath(file.getAbsolutePath());
					lista.add(d);
				}
				tbl.setItems(FXCollections.observableArrayList(lista));
			}
		}
	}
	
	@FXML
	public void abreDiretorio() {
		DirectoryChooser dc = new DirectoryChooser();
		File selecionado = dc.showDialog(null);
		if(selecionado != null) {
			txtPath.setText(selecionado.getAbsolutePath());
		}
	}
	
	private void iniciaTabela() {
		colNome.setCellValueFactory(cellData ->
		cellData.getValue().nomeProperty());
			
		coltamanho.setCellValueFactory(cellData ->
		cellData.getValue().tamanhoProperty());
	}
}
