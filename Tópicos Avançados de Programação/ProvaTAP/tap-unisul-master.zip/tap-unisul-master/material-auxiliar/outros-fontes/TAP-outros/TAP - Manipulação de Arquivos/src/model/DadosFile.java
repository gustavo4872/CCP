package model;

import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;

public class DadosFile {

	SimpleStringProperty nome = new SimpleStringProperty("");
	SimpleIntegerProperty tamanho = new SimpleIntegerProperty();
	SimpleStringProperty path = new SimpleStringProperty("");
	
	public final SimpleStringProperty nomeProperty() {
		return this.nome;
	}
	
	public final String getNome() {
		return this.nomeProperty().get();
	}
	
	public final void setNome(final String nome) {
		this.nomeProperty().set(nome);
	}
	
	public final SimpleIntegerProperty tamanhoProperty() {
		return this.tamanho;
	}
	
	public final int getTamanho() {
		return this.tamanhoProperty().get();
	}
	
	public final void setTamanho(final int tamanho) {
		this.tamanhoProperty().set(tamanho);
	}

	public final SimpleStringProperty pathProperty() {
		return this.path;
	}
	

	public final String getPath() {
		return this.pathProperty().get();
	}
	

	public final void setPath(final String path) {
		this.pathProperty().set(path);
	}
	
	
	
	
}
