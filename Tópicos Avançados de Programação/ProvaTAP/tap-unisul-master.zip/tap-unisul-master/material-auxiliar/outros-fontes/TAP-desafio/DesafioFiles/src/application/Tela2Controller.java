package application;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.ArrayList;

import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import model.Transporte;

public class Tela2Controller {
	
	@FXML TextField txtDistancia;
	@FXML TextField txtCusto;
	
	@FXML RadioButton rdPublico;
	@FXML RadioButton rdProprio;
	
	@FXML TableView<Transporte> tbl;
	@FXML TableColumn<Transporte, String> colTipo;
	@FXML TableColumn<Transporte, Number> colDistancia;
	@FXML TableColumn<Transporte, Number> colCusto;
	
	private ArrayList<Transporte> transportes = new ArrayList<Transporte>();
	
	@FXML
	public void initialize() {
		inicializaTabela();
		leArquivo();
	}
	
	@FXML
	public void inicializaTabela() {
		colTipo.setCellValueFactory(cellData -> cellData.getValue().tipoProperty());
		colDistancia.setCellValueFactory(cellData -> cellData.getValue().distanciaProperty());
		colCusto.setCellValueFactory(cellData -> cellData.getValue().custoProperty());
	}
	
	@FXML
	public void grava() {
		try {
			Transporte t = new Transporte();
			
			if(rdPublico.isSelected()) {
				t.setTipo("Publico");
			}else if(rdProprio.isSelected()) {
				t.setTipo("Proprio");
			}
			
			try {
				t.setDistancia(Double.parseDouble(txtDistancia.getText()));
				
				try {
					t.setCusto(Double.parseDouble(txtCusto.getText()));

					FileWriter fw = new FileWriter("transportes.txt",true);
					BufferedWriter bw = new BufferedWriter(fw);
					bw.append(t.getTipo()+","+t.getDistancia()+","+t.getCusto()+"\n");
					bw.close();
					fw.close();
					
					leArquivo();
					
				}catch(NumberFormatException e) {
					mostraMensagem("NUMBER FORMAT EXCEPTION", AlertType.WARNING);
					txtCusto.requestFocus();
					txtCusto.selectAll();
				}
				catch (Exception e){
					e.printStackTrace();
				}
			}catch(NumberFormatException e) {
				mostraMensagem("NUMBER FORMAT EXCEPTION", AlertType.WARNING);
				txtDistancia.requestFocus();
				txtDistancia.selectAll();
			}
			catch(Exception e) {
				e.printStackTrace();
			}
			
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	@FXML
	private void leArquivo() {
		transportes.clear();
		try {
			FileReader fr = new FileReader("transportes.txt");
			BufferedReader br = new BufferedReader(fr);
			String linha = "";
			while((linha = br.readLine())!=null) {
				String[] dados = linha.split(",");
				Transporte t = new Transporte();
				t.setTipo(dados[0]);
				t.setDistancia(Double.parseDouble(dados[1]));
				t.setCusto(Double.parseDouble(dados[2]));
				transportes.add(t);
			}
			br.close();
			fr.close();
			tbl.setItems(FXCollections.observableArrayList(transportes));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	private void mostraMensagem(String msg, AlertType tipo) {
		Alert a = new Alert(tipo);
		a.setHeaderText(null);
		a.setTitle(null);
		a.setContentText(msg);
		a.show();
	}
}

/* mostraMensagem("ERRO N�O IDENTIFICADO", AlertType.WARNING);
txtPosicao.requestFocus();
txtPosicao.selectAll();
}
}

private void mostraMensagem(String msg, AlertType tipo) {
Alert a = new Alert(tipo);
a.setHeaderText(null);
a.setTitle(null);
a.setContentText(msg);
a.show();
}*/
