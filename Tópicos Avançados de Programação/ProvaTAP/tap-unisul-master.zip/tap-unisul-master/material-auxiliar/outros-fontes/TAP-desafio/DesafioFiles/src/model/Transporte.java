package model;

import javafx.beans.property.DoubleProperty;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class Transporte {

	private DoubleProperty distancia = new SimpleDoubleProperty(0);
	private StringProperty tipo = new SimpleStringProperty("");
	private DoubleProperty custo = new SimpleDoubleProperty(0);
	
	
	public final DoubleProperty distanciaProperty() {
		return this.distancia;
	}
	
	public final double getDistancia() {
		return this.distanciaProperty().get();
	}
	
	public final void setDistancia(final double distancia) {
		this.distanciaProperty().set(distancia);
	}
	
	public final StringProperty tipoProperty() {
		return this.tipo;
	}
	
	public final String getTipo() {
		return this.tipoProperty().get();
	}
	
	public final void setTipo(final String tipo) {
		this.tipoProperty().set(tipo);
	}
	
	public final DoubleProperty custoProperty() {
		return this.custo;
	}
	
	public final double getCusto() {
		return this.custoProperty().get();
	}
	
	public final void setCusto(final double custo) {
		this.custoProperty().set(custo);
	}
	

}
