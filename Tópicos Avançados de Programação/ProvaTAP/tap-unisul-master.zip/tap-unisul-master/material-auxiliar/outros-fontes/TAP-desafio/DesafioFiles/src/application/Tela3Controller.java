package application;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.ArrayList;

import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import model.Aluno;
import model.Transporte;

public class Tela3Controller {

	private ArrayList<Aluno> alunos = new ArrayList<Aluno>();
	private ArrayList<Transporte> transportes = new ArrayList<Transporte>();
	private ArrayList<String> todos = new ArrayList<String>();
	
	/*
	@FXML
	public void initialize() {
		leTodos();
	}
	*/
	@FXML
	private void leArquivoAlunos() {
		alunos.clear();
		try {
			FileReader fr = new FileReader("alunos.txt");
			BufferedReader br = new BufferedReader(fr);
			String linha = "";
			while((linha = br.readLine())!=null) {
				String[] dados = linha.split(",");
				Aluno a = new Aluno();
				a.setNome(dados[0]);
				a.setSemestre(Integer.parseInt(dados[1]));
				a.setCurso(dados[2]);
				alunos.add(a);
			}
			br.close();
			fr.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@FXML
	private void leArquivoTransportes() {
		transportes.clear();
		try {
			FileReader fr = new FileReader("transportes.txt");
			BufferedReader br = new BufferedReader(fr);
			String linha = "";
			while((linha = br.readLine())!=null) {
				String[] dados = linha.split(",");
				Transporte t = new Transporte();
				t.setTipo(dados[0]);
				t.setDistancia(Double.parseDouble(dados[1]));
				t.setCusto(Double.parseDouble(dados[2]));
				transportes.add(t);
			}
			br.close();
			fr.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@FXML
	public void unir() {
		leArquivoAlunos();
		leArquivoTransportes();
		
		try {
			int contA=0;
			int contT=0;
			boolean aux=false;
			
			for (Aluno a : alunos) {
				for (Transporte t : transportes) {
					if(contA == contT) {
						if(aux==false) {
							FileWriter fw = new FileWriter("todos.txt");
							BufferedWriter bw = new BufferedWriter(fw);
							bw.append(a.getNome()+","+a.getSemestre()+","+a.getCurso()+","+t.getTipo()+","+t.getDistancia()+","+t.getCusto()+"\n");
							bw.close();
							fw.close();
							aux=true;
						}else {
							FileWriter fw = new FileWriter("todos.txt",true);
							BufferedWriter bw = new BufferedWriter(fw);
							bw.append(a.getNome()+","+a.getSemestre()+","+a.getCurso()+","+t.getTipo()+","+t.getDistancia()+","+t.getCusto()+"\n");
							bw.close();
							fw.close();
						}
					}
					contT++;
				}
				contA++;
				contT=0;
			}
			
			if(alunos.size() > transportes.size()) {
				mostraMensagem("ADICIONE OS TRANSPORTES RESTANTES", AlertType.WARNING);
			}else if(alunos.size() < transportes.size()) {
				mostraMensagem("ADICIONE OS ALUNOS RESTANTES", AlertType.WARNING);
			}else if(alunos.size() == transportes.size()) {
				mostraMensagem("SUCESSO, CONFIRA O ARQUIVO TODOS.TXT", AlertType.INFORMATION);
			}
			
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public void leTodos() {
		try {
			FileReader fr = new FileReader("todos.txt");
			BufferedReader br = new BufferedReader(fr);
			String linha = "";
			while((linha = br.readLine())!=null) {
				String[] dados = linha.split(",");
				todos.add(dados[0]);
				todos.add(dados[1]);
				todos.add(dados[2]);
			}
			br.close();
			fr.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	private void mostraMensagem(String msg, AlertType tipo) {
		Alert a = new Alert(tipo);
		a.setHeaderText(null);
		a.setTitle(null);
		a.setContentText(msg);
		a.show();
	}
	
}
