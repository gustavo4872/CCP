package ExercicioProperties;

import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.Properties;

import javafx.fxml.FXML;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Border;
import javafx.scene.layout.BorderPane;

public class Tela2Controller {
	
	String razaoSocial ="";
	String cor ="";
	String logo ="";
	Integer largura =0;
	Integer altura =0;
	
	@FXML Label lbRazao;
	@FXML ImageView img;
	@FXML AnchorPane pane;
	

	public void initialize()
	{
		leArquivo();
		pane.setMinWidth(largura);
		pane.setMinHeight(altura);
		lbRazao.setText(razaoSocial);
		try {
			img.setImage(new Image(new FileInputStream(logo)));
		} catch (Exception e) {
			e.printStackTrace();
		}
		pane.setStyle("-fx-background-color: #"+cor);//cor.substring(4)
	}
	
	public void leArquivo() 
	{
		Properties properties = new Properties();
		try 
		{
			FileReader fr = new FileReader("conf.properties");
			properties.load(fr);
			razaoSocial = properties.getProperty("Razao");
			cor = properties.getProperty("Cor");
			logo = properties.getProperty("Logo");
			altura = Integer.parseInt(properties.getProperty("Altura"));
			largura = Integer.parseInt(properties.getProperty("largura"));
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		}
	}
	
	public void alteraTela() 
	{
		try 
		{
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		}
	}

}
