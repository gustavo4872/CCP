package model;
import java.sql.Date;
import java.text.SimpleDateFormat;

import javafx.beans.property.BooleanProperty;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.scene.control.DatePicker;

public class Competicoes {
	
	private StringProperty nome = new SimpleStringProperty("");
	private DatePicker data;
	private StringProperty distancia = new SimpleStringProperty("");
	private IntegerProperty colocacao = new SimpleIntegerProperty(0);
	private IntegerProperty melhorcolocacao = new SimpleIntegerProperty(0);
	
	
	public final StringProperty nomeProperty() {
		return this.nome;
	}
	
	public final String getNome() {
		return this.nomeProperty().get();
	}
	
	public final void setNome(final String nome) {
		this.nomeProperty().set(nome);
	}
	
	public final StringProperty distanciaProperty() {
		return this.distancia;
	}
	
	public final String getDistancia() {
		return this.distanciaProperty().get();
	}
	
	public final void setDistancia(final String distancia) {
		this.distanciaProperty().set(distancia);
	}
	
	public final IntegerProperty colocacaoProperty() {
		return this.colocacao;
	}
	
	public final int getColocacao() {
		return this.colocacaoProperty().get();
	}
	
	public final void setColocacao(final int colocacao) {
		this.colocacaoProperty().set(colocacao);
	}
	
	public final IntegerProperty melhorcolocacaoProperty() {
		return this.melhorcolocacao;
	}
	
	public final int getMelhorcolocacao() {
		return this.melhorcolocacaoProperty().get();
	}
	
	public final void setMelhorcolocacao(final int melhorcolocacao) {
		this.melhorcolocacaoProperty().set(melhorcolocacao);
	}

	public DatePicker getData() {
		return data;
	}

	public void setData(DatePicker data) {
		this.data = data;
	}
	
	
	

	
}
