package ExercicioDadosFile;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.util.ArrayList;

import javafx.fxml.FXML;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;

public class Tela2Controller {
	
	@FXML CheckBox ckProprio;
	@FXML CheckBox ckPublico;
	
	@FXML TextField txtDistancia;
	@FXML TextField txtCusto;
	
	
	public void initialize()
	{
		
	}
	
	public void inserir() {
		try {
			Transporte t = new Transporte();
			t.setProprio(ckProprio.isSelected());
			t.setPublico(ckPublico.isSelected());
			t.setDistancia(Double.parseDouble(txtDistancia.getText()));
			t.setCusto(Double.parseDouble(txtCusto.getText()));
			FileWriter fw = new FileWriter("transporte.txt",true);
			BufferedWriter bw = new BufferedWriter(fw);
			bw.append(t.isProprio()+","+t.isPublico()+","+t.getDistancia()+","+t.getCusto()+"\r\n");
			bw.close();
			fw.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
