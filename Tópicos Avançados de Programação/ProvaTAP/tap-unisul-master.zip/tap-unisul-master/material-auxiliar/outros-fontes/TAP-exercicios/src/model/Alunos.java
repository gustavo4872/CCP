package model;

import javafx.beans.property.BooleanProperty;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class Alunos {
	
	private StringProperty nome = new SimpleStringProperty("");
	private StringProperty semestre = new SimpleStringProperty("");
	private StringProperty curso = new SimpleStringProperty("");
	private StringProperty sexo = new SimpleStringProperty("");
	private StringProperty nasc = new SimpleStringProperty("");
	private StringProperty uf = new SimpleStringProperty("");
	private BooleanProperty mat = new SimpleBooleanProperty(false);
	private BooleanProperty vesp = new SimpleBooleanProperty(false);
	private BooleanProperty not = new SimpleBooleanProperty(false);
	private IntegerProperty idade = new SimpleIntegerProperty(0);	
	
	
	public final StringProperty nomeProperty() {
		return this.nome;
	}
	
	public final String getNome() {
		return this.nomeProperty().get();
	}
	
	public final void setNome(final String nome) {
		this.nomeProperty().set(nome);
	}
	
	public final StringProperty sexoProperty() {
		return this.sexo;
	}
	
	public final String getSexo() {
		return this.sexoProperty().get();
	}
	
	public final void setSexo(final String sexo) {
		this.sexoProperty().set(sexo);
	}
	
	public final StringProperty nascProperty() {
		return this.nasc;
	}
	
	public final String getNasc() {
		return this.nascProperty().get();
	}
	
	public final void setNasc(final String nasc) {
		this.nascProperty().set(nasc);
	}
	
	public final StringProperty ufProperty() {
		return this.uf;
	}
	
	public final String getUf() {
		return this.ufProperty().get();
	}
	
	public final void setUf(final String uf) {
		this.ufProperty().set(uf);
	}
	
	public final BooleanProperty matProperty() {
		return this.mat;
	}
	
	public final boolean isMat() {
		return this.matProperty().get();
	}
	
	public final void setMat(final boolean mat) {
		this.matProperty().set(mat);
	}
	
	public final BooleanProperty vespProperty() {
		return this.vesp;
	}
	
	public final boolean isVesp() {
		return this.vespProperty().get();
	}
	
	public final void setVesp(final boolean vesp) {
		this.vespProperty().set(vesp);
	}
	
	public final BooleanProperty notProperty() {
		return this.not;
	}
	
	public final boolean isNot() {
		return this.notProperty().get();
	}
	
	public final void setNot(final boolean not) {
		this.notProperty().set(not);
	}

	public final IntegerProperty idadeProperty() {
		return this.idade;
	}
	

	public final int getIdade() {
		return this.idadeProperty().get();
	}

	public final void setIdade(final int idade) {
		this.idadeProperty().set(idade);
	}

	public final StringProperty semestreProperty() {
		return this.semestre;
	}
	

	public final String getSemestre() {
		return this.semestreProperty().get();
	}
	

	public final void setSemestre(final String semestre) {
		this.semestreProperty().set(semestre);
	}
	

	public final StringProperty cursoProperty() {
		return this.curso;
	}
	

	public final String getCurso() {
		return this.cursoProperty().get();
	}
	

	public final void setCurso(final String curso) {
		this.cursoProperty().set(curso);
	}
	
	
	
	
}
