package Persistencia1;

import java.io.File;
import java.sql.Date;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;

import com.sun.glass.events.MouseEvent;

import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.control.Alert;
import javafx.scene.control.CheckBox;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.GridPaneBuilder;
import javafx.stage.DirectoryChooser;
import model.DadosFile;
import model.Competicoes;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.DatePicker;
import javafx.scene.control.ProgressBar;
import javafx.scene.control.ComboBox;
public class Persistencia1Controller {
	
	@FXML private TextField txtLocal;
	
	@FXML TableView<DadosFile> tb1;
	@FXML TableColumn<DadosFile,String> colNome;
	@FXML TableColumn<DadosFile,String> colTam;
	
	private ArrayList<DadosFile> lista = new ArrayList<DadosFile>();
	
	@FXML
	public void initialize()
	{
		inicializaTb1();
	}
	
	
	@FXML
	public void abreDiretorio()
	{
		DirectoryChooser dc = new DirectoryChooser();
		File selecionado = dc.showDialog(null);
		if(selecionado != null)
		{
			txtLocal.setText(selecionado.getAbsolutePath());
		}
	}
	
	@FXML
	public void listar()
	{
		if(!txtLocal.getText().equals(""))
		{
			File diretorio = new File(txtLocal.getText());
			if(diretorio.isDirectory())
			{
				lista.clear();
				File[] v = diretorio.listFiles();
				for (File f : v) 
				{
					DadosFile d = new DadosFile();
					d.setNome(f.getName());
					d.setTam(f.length()+" Bytes");
					d.setPath(f.getAbsolutePath());
					lista.add(d);
				}
				tb1.setItems(FXCollections.observableArrayList(lista));
			}
		}
	}
	
	@FXML
	public void apagaLinhaSelecionada()
	{
		DadosFile df = tb1.getSelectionModel().getSelectedItem();
		if(df != null)
		{
			File f = new File(df.getPath());
			f.delete();
			lista.remove(df);
			tb1.setItems(FXCollections.observableArrayList(lista));
		}
	}
	
	@FXML
	public void apagaTodos()
	{
		for (DadosFile df : tb1.getItems()) {
			File f = new File(df.getPath());
			f.delete();
		}
		lista.clear();
		tb1.setItems(FXCollections.observableArrayList(lista));
	}
	
	
	private void inicializaTb1()
	{
		colNome.setCellValueFactory(cellData -> cellData.getValue().nomeProperty());
		colTam.setCellValueFactory(cellData -> cellData.getValue().tamProperty());
	}

}
