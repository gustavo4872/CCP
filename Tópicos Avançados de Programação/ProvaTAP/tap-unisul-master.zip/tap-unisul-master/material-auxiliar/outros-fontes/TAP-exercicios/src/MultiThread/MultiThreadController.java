package MultiThread;
import java.sql.Date;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;

import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.CheckBox;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import model.Trabalhador;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.DatePicker;
import javafx.scene.control.ProgressBar;
import javafx.scene.control.ComboBox;
public class MultiThreadController {

	@FXML private TextField t1QT;
	@FXML private TextField t1Tempo;
	@FXML private ProgressBar p1;
	
	@FXML private TextField t2QT;
	@FXML private TextField t2Tempo;
	@FXML private ProgressBar p2;
	
	
	
	
	@FXML
	public void iniciaSemThread()
	{
		int qt1 = Integer.parseInt(t1QT.getText());
		int qt2 = Integer.parseInt(t2QT.getText());
		int tp1 = Integer.parseInt(t1Tempo.getText());
		int tp2 = Integer.parseInt(t2Tempo.getText());
		
		Trabalhador t1 = new Trabalhador(qt1, tp1, p1);
		Trabalhador t2 = new Trabalhador(qt2, tp2, p2);
		t1.inicia();
		t2.inicia();
	}
	
	@FXML
	public void iniciaComThread()
	{
		int qt1 = Integer.parseInt(t1QT.getText());
		int qt2 = Integer.parseInt(t2QT.getText());
		int tp1 = Integer.parseInt(t1Tempo.getText());
		int tp2 = Integer.parseInt(t2Tempo.getText());
		
		Trabalhador t1 = new Trabalhador(qt1, tp1, p1);
		Trabalhador t2 = new Trabalhador(qt2, tp2, p2);
		new Thread(t1).start();
		new Thread(t2).start();
	}
	
}


