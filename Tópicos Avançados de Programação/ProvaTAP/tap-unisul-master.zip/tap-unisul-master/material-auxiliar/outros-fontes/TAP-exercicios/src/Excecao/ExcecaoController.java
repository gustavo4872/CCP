package Excecao;
import java.sql.Date;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;

import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.CheckBox;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.DatePicker;
import javafx.scene.control.ComboBox;
public class ExcecaoController {

	@FXML TextField txtNumero;
	@FXML TextField txtPosicao;
	@FXML TextField txtTamanho;
	
	private int[] vetor;
	
	@FXML
	public void instaciaVetor()
	{
		try 
		{
			if(Integer.parseInt(txtTamanho.getText()) > 10)
				throw new NumberFormatException("Limite 10");
			vetor = new int[Integer.parseInt(txtTamanho.getText())];
			
		}
		catch (NumberFormatException e) 
		{
			mostraMensagem("Erro no Tamanho do Vetor! " + e.toString(),AlertType.ERROR);
			txtTamanho.requestFocus();
			txtTamanho.selectAll();
		}
		catch (NegativeArraySizeException e) 
		{
			mostraMensagem("N�o Pode Ser Negativo! ",AlertType.ERROR);
			txtTamanho.requestFocus();
			txtTamanho.selectAll();
		}
		catch (Exception e) 
		{
			mostraMensagem("Erro n�o Identificado: " + e.toString(),AlertType.WARNING);
		}
		
	}
	
	@FXML
	public void inserir()
	{
		try 
		{
			int numero = Integer.parseInt(txtNumero.getText());
			int posicao = Integer.parseInt(txtPosicao.getText());
			vetor[posicao] = numero;
			mostraMensagem("N�mero inserido com Sucesso!" ,AlertType.INFORMATION);
		} 
		catch (NumberFormatException e) 
		{
			mostraMensagem("ERRO DE CONVERSAO NUMERICA!",AlertType.ERROR);
		}
		catch (NegativeArraySizeException e) 
		{
			mostraMensagem("Campo Posi��o n�o pode ser Negativo!",AlertType.ERROR);
		}
		catch (NullPointerException e) 
		{
			mostraMensagem("Vetor N�o instaciado!",AlertType.ERROR);
		}
		catch (ArrayIndexOutOfBoundsException e) 
		{
			mostraMensagem("Posi��o N�o Existente no Vetor! ",AlertType.ERROR);
		}
		
		catch (Exception e) 
		{
			mostraMensagem("Erro n�o identificado: " + e.toString(),AlertType.WARNING);
		}
		
	}
	
	private void mostraMensagem(String msg, AlertType tipo)
	{
		Alert a = new  Alert(tipo);
		a.setHeaderText(null);
		a.setContentText(msg);
		a.show();
	}
	
}


