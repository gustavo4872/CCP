package SimuladoExer2;

import java.sql.Date;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;

import com.sun.glass.events.MouseEvent;

import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.control.Alert;
import javafx.scene.control.CheckBox;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.GridPaneBuilder;
import model.Atleta;
import model.Competicoes;
import model.Trabalhador;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.DatePicker;
import javafx.scene.control.ProgressBar;
import javafx.scene.control.ComboBox;
public class CompeticaoController {

	@FXML private TextField txtNome;
	@FXML private DatePicker txtData;
	@FXML private TextField txtDistancia;
	@FXML private TextField txtColocacao;
	@FXML private TextField txtMelhorColocacao;
	
	@FXML TableView<Competicoes> tb1;
	@FXML TableColumn<Competicoes,String> colNome;
	@FXML TableColumn<Competicoes,String> colData;
	@FXML TableColumn<Competicoes,String> colDistancia;
	@FXML TableColumn<Competicoes,Integer> colColocacao;
	
	private ArrayList<Competicoes> competicoes = new ArrayList<Competicoes>();
	private int melhor = 100000000;
	@FXML
	public void initilize()
	{
		inicializaTb1();
	}
	
	@FXML
	public void incluir()
	{
		Competicoes c = new Competicoes();
		c.setNome(txtNome.getText());
		c.setData(txtData);
		c.setDistancia(txtDistancia.getText());
		c.setColocacao(Integer.parseInt(txtColocacao.getText()));
		competicoes.add(c);
		inicializaTb1();
		tb1.setItems(FXCollections.observableArrayList(competicoes));
		for (Competicoes a : competicoes) 
		{
			int atual =a.getColocacao();
			if(atual < melhor)
			{
				melhor = atual;
			}
		}
		txtMelhorColocacao.setText(Integer.toString(melhor));
	}
	@FXML
	public void remove()
	{
		tb1.setOnMouseClicked( event -> {
			   if( event.getClickCount() == 2 ) {
				   int count =0;
					int indremovido = tb1.getSelectionModel().getSelectedIndex();
					melhor = 100000000;
					for (Competicoes a : competicoes) 
					{
						if(count == indremovido)
						{
							competicoes.remove(indremovido);
						}
						count++;
					}
					tb1.setItems(FXCollections.observableArrayList(competicoes));
					
					//coloca a melhor colocacao
					for (Competicoes a : competicoes) 
					{
						int atual =a.getColocacao();
						if(atual < melhor)
						{
							melhor = atual;
						}
					}
					if(melhor <100000000)
					{
						txtMelhorColocacao.setText(Integer.toString(melhor));
					}
					else
					{
						txtMelhorColocacao.setText(Integer.toString(0));
					}
					
			   }});
	}
	
	private void inicializaTb1()
	{
		colNome.setCellValueFactory(cellData -> cellData.getValue().nomeProperty());
		//colData.setCellValueFactory(cellData -> cellData.getValue());
		colDistancia.setCellValueFactory(cellData -> cellData.getValue().distanciaProperty());
		colColocacao.setCellValueFactory(cellData -> cellData.getValue().colocacaoProperty().asObject());
		
	}
}
