package model;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.scene.control.DatePicker;

public class DadosFile {
	private StringProperty nome = new SimpleStringProperty("");
	private StringProperty tam = new SimpleStringProperty("");
	private StringProperty path = new SimpleStringProperty("");
	
	
	
	public final StringProperty nomeProperty() {
		return this.nome;
	}
	
	public final String getNome() {
		return this.nomeProperty().get();
	}
	
	public final void setNome(final String nome) {
		this.nomeProperty().set(nome);
	}
	
	public final StringProperty tamProperty() {
		return this.tam;
	}
	
	public final String getTam() {
		return this.tamProperty().get();
	}
	
	public final void setTam(final String tam) {
		this.tamProperty().set(tam);
	}

	public final StringProperty pathProperty() {
		return this.path;
	}
	

	public final String getPath() {
		return this.pathProperty().get();
	}
	

	public final void setPath(final String path) {
		this.pathProperty().set(path);
	}
	


	
}
