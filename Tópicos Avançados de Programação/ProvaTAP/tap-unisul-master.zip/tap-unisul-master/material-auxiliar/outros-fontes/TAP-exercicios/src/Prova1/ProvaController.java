package Prova1;

import java.sql.Date;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;

import javax.swing.JOptionPane;
import javax.swing.text.NumberFormatter;

import com.sun.glass.events.MouseEvent;

import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.control.Alert;
import javafx.scene.control.CheckBox;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.GridPaneBuilder;
import model.Atleta;
import model.Competicoes;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.DatePicker;
import javafx.scene.control.ProgressBar;
import javafx.scene.control.ComboBox;
import Prova1.Funcionarios;
public class ProvaController {

	@FXML private ComboBox<String> cbNome;
	@FXML private TextField txtQtdProd;
	@FXML private TextField txtTempo;
	
	@FXML private ProgressBar p1;
	@FXML private ProgressBar p2;
	@FXML private ProgressBar p3;
	
	@FXML TableView<Funcionarios> tb1;
	@FXML TableColumn<Funcionarios,String> colFuncionario;
	@FXML TableColumn<Funcionarios,Integer> colQuantidade;
	@FXML TableColumn<Funcionarios,Integer> colTempo;
	
	private ArrayList<Funcionarios> func = new ArrayList<Funcionarios>();
	
	@FXML
	public void initilize()
	{
		inicializaCombo();
	}
	
	@FXML
	public void adicionar()
	{
		if(valida(cbNome.getSelectionModel().getSelectedItem()) == true)
		{
			try 
			{
				if(Integer.parseInt(txtQtdProd.getText()) <= 0)
				{
					throw new NumberFormatException("Quantidade N�o pode Ser Negativo ou Zero!");
				}
				if(Integer.parseInt(txtTempo.getText()) <= 0)
				{
					throw new NumberFormatException("Tempo N�o pode Ser Negativo ou Zero!");
				}
				Funcionarios f = new Funcionarios();
				f.setNome(cbNome.getSelectionModel().getSelectedItem());
				f.setQtd(Integer.parseInt(txtQtdProd.getText()));
			    f.setTempo(Integer.parseInt(txtTempo.getText()));
				func.add(f);
			} 
			catch (NumberFormatException e) 
			{
				mostraMensagem("ERRO DE CONVERSAO NUMERICA!\r\n" + e.toString(),AlertType.ERROR);
			}
			catch (Exception e) 
			{
				mostraMensagem("Erro n�o identificado: " + e.toString(),AlertType.WARNING);
			}
			inicializaTb1();
			tb1.setItems(FXCollections.observableArrayList(func));
		}
		else
		{
			JOptionPane.showMessageDialog(null, "Funcion�rio J� Cadastrado");
		}
		
	}
	private void inicializaCombo()
	{
		cbNome.getItems().add("Jo�o");
		cbNome.getItems().add("Jos�");
		cbNome.getItems().add("Paulo");
	}
	
	private Boolean valida(String nome)
	{
		Boolean retorno = true;
		
		for (Funcionarios a : func) 
		{
			if(nome.equalsIgnoreCase(a.getNome()))
			{
				retorno = false;
			}
		}
		
		return retorno;
		
	}
	
	private void mostraMensagem(String msg, AlertType tipo)
	{
		Alert a = new  Alert(tipo);
		a.setHeaderText(null);
		a.setContentText(msg);
		a.show();
	}
	
	@FXML
	public void iniciaProducao()
	{
		int qt1 = 0;
		int qt2 = 0;
		int qt3 = 0;
		int tp1 = 0;
		int tp2 = 0;
		int tp3 = 0;
		for (Funcionarios a : func) 
		{
			if(a.getNome().equalsIgnoreCase("Jo�o"))
			{
				qt1 = a.getQtd();
				tp1 = a.getTempo();
			}
			if(a.getNome().equalsIgnoreCase("Jos�"))
			{
				qt2 = a.getQtd();
				tp2 = a.getTempo();
			}
			if(a.getNome().equalsIgnoreCase("Paulo"))
			{
				qt3 = a.getQtd();
				tp3 = a.getTempo();
			}
		}
		
	
		if((qt1 > 0) && (tp1 > 0))
		{
			Producao t1 = new Producao(qt1, tp1, p1);
			new Thread(t1).start();
		}
		if((qt2 > 0) && (tp2 > 0))
		{
			Producao t2 = new Producao(qt2, tp2, p2);
			new Thread(t2).start();
		}
		if((qt3 > 0) && (tp3 > 0))
		{
			Producao t3 = new Producao(qt3, tp3, p3);
			new Thread(t3).start();
		}
	
		
	}
	
	private void inicializaTb1()
	{
		colFuncionario.setCellValueFactory(cellData -> cellData.getValue().nomeProperty());
		colQuantidade.setCellValueFactory(cellData -> cellData.getValue().qtdProperty().asObject());
		colTempo.setCellValueFactory(cellData -> cellData.getValue().tempoProperty().asObject());
		
	}
}
