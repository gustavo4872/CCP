package Prova1;

import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class Funcionarios {
	
	private StringProperty nome = new SimpleStringProperty("");
	private IntegerProperty qtd = new SimpleIntegerProperty(0);
	private IntegerProperty tempo = new SimpleIntegerProperty(0);
	public final StringProperty nomeProperty() {
		return this.nome;
	}
	
	public final String getNome() {
		return this.nomeProperty().get();
	}
	
	public final void setNome(final String nome) {
		this.nomeProperty().set(nome);
	}
	
	public final IntegerProperty qtdProperty() {
		return this.qtd;
	}
	
	public final int getQtd() {
		return this.qtdProperty().get();
	}
	
	public final void setQtd(final int qtd) {
		this.qtdProperty().set(qtd);
	}
	
	public final IntegerProperty tempoProperty() {
		return this.tempo;
	}
	
	public final int getTempo() {
		return this.tempoProperty().get();
	}
	
	public final void setTempo(final int tempo) {
		this.tempoProperty().set(tempo);
	}
	
	
	
}
