package ExercicioProperties;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.Properties;

import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.ColorPicker;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.stage.FileChooser;
import javafx.stage.FileChooser.ExtensionFilter;
import model.DadosFile;
public class Tela1Controller {
	
	@FXML TextField txtLargura;
	@FXML TextField txtAltura;
	@FXML TextField txtEndLogotipo;
	@FXML ColorPicker clCor;
	@FXML TextField txtRazao;
	
	@FXML
	public void initialize()
	{
		
	}
	
	public void inserir() {
		try {
			File f = new File(txtEndLogotipo.getText());
			if(f.isFile())
			{
				Properties proper = new Properties();
				proper.setProperty("Largura", txtLargura.getText());
				proper.setProperty("Altura", txtAltura.getText());
				proper.setProperty("Logo", txtEndLogotipo.getText());
				proper.setProperty("Cor", Integer.toHexString(clCor.getValue().hashCode()));
				proper.setProperty("Razao", txtRazao.getText());
				try {
					FileWriter fw = new FileWriter("conf.properties");
					proper.store(fw, "Arquivo de Configura��o");
					fw.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void abreDiretorio()
	{
		FileChooser fc = new FileChooser();
		File Selecionado =fc.showOpenDialog(null);
		if(Selecionado!=  null)
		{
			txtEndLogotipo.setText(Selecionado.getAbsolutePath());
		}
	}
	public File abreDiretorioClavison()
	{
		FileChooser fc = new FileChooser();
		fc.getExtensionFilters().add(new 
			ExtensionFilter("Imagens","*.jpg","*.JPG",
						"*.png","*.PNG","*.gif","*.GIF"));
		fc.setInitialDirectory(new File("C:\\Users\\Marcus Willian Alves\\Desktop\\Screen-Shot-2017-10-01-at-7.47.26-AM.png"));
		File imgSelec = fc.showOpenDialog(null);
		try {
			if(imgSelec != null)
				return imgSelec;
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
		
	}
	
}
