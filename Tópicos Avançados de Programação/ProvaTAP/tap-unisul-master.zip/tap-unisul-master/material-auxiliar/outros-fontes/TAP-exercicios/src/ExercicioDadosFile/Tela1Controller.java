package ExercicioDadosFile;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.ArrayList;

import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import model.DadosFile;
public class Tela1Controller {
	
	@FXML TextField txtNome;
	@FXML TextField txtSemestre;
	@FXML TextField txtCurso;
	
	@FXML TableView<Alunos> tb1;
	@FXML TableColumn<Alunos,String> colNome;
	@FXML TableColumn<Alunos,Integer> colSemestre;
	@FXML TableColumn<Alunos,String> colCurso;
	
	private ArrayList<Alunos> alunos = new ArrayList<Alunos>();
	
	@FXML
	public void initialize()
	{
		leArquivo();
	}
	
	public void leArquivo() {
		alunos.clear();
		try {
			FileReader fr = new FileReader("alunos.txt");
			BufferedReader br = new BufferedReader(fr);
			String linha = "";
			while((linha = br.readLine())!=null) {
				String[] dados = linha.split(",");
				Alunos a = new Alunos();
				a.setNome(dados[0]);
				a.setSemestre(Integer.parseInt(dados[1]));
				a.setCurso(dados[2]);
				alunos.add(a);
			}
			br.close();
			fr.close();
			inicializaTb1();
			tb1.setItems(FXCollections.observableArrayList(alunos));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void inserir() {
		try {
			Alunos a = new Alunos();
			a.setNome(txtNome.getText());
			a.setSemestre(Integer.parseInt(txtSemestre.getText()));
			a.setCurso(txtCurso.getText());
			FileWriter fw = new FileWriter("alunos.txt",true);
			BufferedWriter bw = new BufferedWriter(fw);
			bw.append(a.getNome()+","+a.getSemestre()+","+a.getCurso()+"\r\n");
			bw.close();
			fw.close();
			leArquivo();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	
	public void inicializaTb1()
	{
		colNome.setCellValueFactory(cellData -> cellData.getValue().nomeProperty());
		colSemestre.setCellValueFactory(cellData -> cellData.getValue().semestreProperty().asObject());
		colCurso.setCellValueFactory(cellData -> cellData.getValue().cursoProperty());
		
	}
}
