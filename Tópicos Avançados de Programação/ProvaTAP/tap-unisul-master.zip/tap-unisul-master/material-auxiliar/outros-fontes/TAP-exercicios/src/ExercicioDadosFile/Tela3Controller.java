package ExercicioDadosFile;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;

import javafx.collections.FXCollections;
import javafx.fxml.FXML;

public class Tela3Controller {

	@FXML
	public void initialize()
	{
		
	}
	
	public void uniArquivos() {
		try {
			FileReader frAlunos = new FileReader("alunos.txt");
			BufferedReader brAlunos = new BufferedReader(frAlunos);
			FileReader frTransp = new FileReader("transporte.txt");
			BufferedReader brTransp = new BufferedReader(frTransp);
			String linhaAlunos = "";
			String linhaTransp = "";
			String concatAlunos = "";
			String concatTransp = "";
			while((linhaAlunos = brAlunos.readLine())!=null) 
			{
				concatAlunos += linhaAlunos+",";
			}
			while((linhaTransp = brTransp.readLine())!=null) 
			{
				concatTransp += linhaTransp+",";
			}
			FileWriter fw = new FileWriter("todos.txt",true);
			BufferedWriter bw = new BufferedWriter(fw);
			bw.append(concatAlunos+concatTransp+"\r\n");
			bw.close();
			fw.close();
			brAlunos.close();
			frAlunos.close();
			brTransp.close();
			frTransp.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
