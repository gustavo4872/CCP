package view;

import javafx.fxml.FXML;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;

public class ImcController {
	@FXML TextField txtNome;
	@FXML TextField txtPeso;
	@FXML TextField txtAltura;
	@FXML TextField txtResultado;
	@FXML RadioButton rdMasc;
	@FXML RadioButton rdFem;
	
	
	@FXML
	public void calcularImc() 
	{
		if(txtNome.getText() != "" && txtPeso.getText() != "" && txtAltura.getText() != "")
		{
			double peso = Double.parseDouble(txtPeso.getText());
			double altura = Double.parseDouble(txtAltura.getText());
			double imc = peso / (altura * altura);
			if(rdFem.isSelected())
			{
				txtResultado.setText("Senhora: " +txtNome.getText() +"\nIMC:"+ imc+"");
			}
			else
			{
				txtResultado.setText("Senhor: " +txtNome.getText() +"\nIMC:"+ imc+"");
			}
		}
	}
	
	public void limparImc()
	{
		txtNome.setText("");
		txtPeso.setText("");
		txtAltura.setText("");
		txtResultado.setText("");
		rdMasc.setSelected(false);
		rdFem.setSelected(false);
	}
	
}
