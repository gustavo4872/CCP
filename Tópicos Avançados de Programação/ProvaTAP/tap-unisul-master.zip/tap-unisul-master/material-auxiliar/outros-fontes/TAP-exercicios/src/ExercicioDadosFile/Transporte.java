package ExercicioDadosFile;

import javafx.beans.property.BooleanProperty;
import javafx.beans.property.DoubleProperty;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class Transporte {

	private BooleanProperty proprio = new SimpleBooleanProperty(false);
	private BooleanProperty publico = new SimpleBooleanProperty(false);
	private DoubleProperty distancia = new SimpleDoubleProperty(0);
	private DoubleProperty custo = new SimpleDoubleProperty(0);
	public final BooleanProperty proprioProperty() {
		return this.proprio;
	}
	
	public final boolean isProprio() {
		return this.proprioProperty().get();
	}
	
	public final void setProprio(final boolean proprio) {
		this.proprioProperty().set(proprio);
	}
	
	public final BooleanProperty publicoProperty() {
		return this.publico;
	}
	
	public final boolean isPublico() {
		return this.publicoProperty().get();
	}
	
	public final void setPublico(final boolean publico) {
		this.publicoProperty().set(publico);
	}
	
	public final DoubleProperty distanciaProperty() {
		return this.distancia;
	}
	
	public final double getDistancia() {
		return this.distanciaProperty().get();
	}
	
	public final void setDistancia(final double distancia) {
		this.distanciaProperty().set(distancia);
	}
	
	public final DoubleProperty custoProperty() {
		return this.custo;
	}
	
	public final double getCusto() {
		return this.custoProperty().get();
	}
	
	public final void setCusto(final double custo) {
		this.custoProperty().set(custo);
	}
	
	
	
}
