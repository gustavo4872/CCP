package view;
import java.sql.Date;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;

import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.CheckBox;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import model.Alunos;
import javafx.scene.control.DatePicker;
import javafx.scene.control.ComboBox;
public class ExemploCadastroController {

	@FXML TextField txtNome;
	@FXML TextField txtFiltro;
	
	@FXML RadioButton rdMasc;
	@FXML RadioButton rdFem;
	
	@FXML DatePicker txtDataNascto;
	
	@FXML ComboBox<String> cbUF;
	
	@FXML CheckBox ckMat;
	@FXML CheckBox ckVesp;
	@FXML CheckBox ckNot;
	
	@FXML TableView<Alunos> tb1;
	@FXML TableColumn<Alunos,String> colNome;
	@FXML TableColumn<Alunos,Number> colIdade;
	@FXML TableColumn<Alunos,String> colSexo;
	@FXML TableColumn<Alunos,String> colMat;
	@FXML TableColumn<Alunos,String> colVesp;
	@FXML TableColumn<Alunos,String> colNot;
	
	private ArrayList<Alunos> alunos = new ArrayList<Alunos>();
	
	
	public void incluir()
	{
		Alunos a = new Alunos();
		a.setNome(txtNome.getText());
		
		a.setSexo(rdMasc.isSelected() ? "M" : "F");
		
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		a.setNasc(dtf.format(txtDataNascto.getValue()));
		//txtDataNascto.getValue().getDayOfMonth() +"/"+ txtDataNascto.getValue().getMonthValue()+"/"+ txtDataNascto.getValue().getYear()
		
		a.setUf(cbUF.getSelectionModel().getSelectedItem());
		a.setMat(ckMat.isSelected());
		a.setVesp(ckVesp.isSelected());
		a.setNot(ckNot.isSelected());
		a.setIdade(calculaIdadeJava8(txtDataNascto.getValue()));
		
		alunos.add(a);
		
		tb1.setItems(FXCollections.observableArrayList(alunos));
	}
	
	private int calculaIdadeJava8(LocalDate dtNasc)
	{
		LocalDate hoje = LocalDate.now();
		long idade = ChronoUnit.YEARS.between(dtNasc, hoje);
		return (int) idade;
	}
	
	private int calculaIdade(String dt)
	{
		DateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		Date dataNascInput = null;		
		try
		{
			dataNascInput = (Date) sdf.parse(dt);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		Calendar dataNasc = new GregorianCalendar();
		dataNasc.setTime(dataNascInput);
		Calendar hoje = Calendar.getInstance();
		int idade = hoje.get(Calendar.YEAR) - dataNasc.get(Calendar.YEAR);
		//dataNasc.add(Calendar.YEAR);
		
		return idade;
	}
	
	public void filtrar()
	{
		if(txtFiltro.getText() == "")
		{
			tb1.setItems(FXCollections.observableArrayList(alunos));
		}
		else
		{
			ArrayList<Alunos> aux = new ArrayList<Alunos>();
			for (Alunos a : alunos) 
			{
				if(a.getNome().toUpperCase().startsWith(txtFiltro.getText().toUpperCase()))
				{
					aux.add(a);
				}
			}
			tb1.setItems(FXCollections.observableArrayList(aux));
		}
	}
	
	@FXML
	public void selecionaAluno()
	{
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		Alunos a = tb1.getSelectionModel().getSelectedItem();
		
		txtNome.setText(a.getNome());
		if(a.getSexo().equalsIgnoreCase("M"))
		{
			rdMasc.setSelected(true);
			rdFem.setSelected(false);
		}
		else
		{
			rdFem.setSelected(true);
			rdMasc.setSelected(false);
		}
		cbUF.getSelectionModel().select(a.getUf());
		txtDataNascto.setValue(LocalDate.parse(a.getNasc(), dtf));
		ckMat.setSelected(a.isMat());
		ckVesp.setSelected(a.isVesp());
		ckNot.setSelected(a.isNot());
	}
	
	@FXML
	public void initilize()
	{
		inicializaComboUF();
		inicializaTb1();
	}
	
	private void inicializaComboUF()
	{
		cbUF.getItems().add("SC");
		cbUF.getItems().add("PR");
		cbUF.getItems().add("RJ");
		cbUF.getItems().add("RS");
		//cbUF.getSelectionModel().select(0);
	}
	
	private void inicializaTb1()
	{
		colNome.setCellValueFactory(cellData -> cellData.getValue().nomeProperty());
		colIdade.setCellValueFactory(cellData -> cellData.getValue().idadeProperty());
		colSexo.setCellValueFactory(cellData -> cellData.getValue().sexoProperty());
		colMat.setCellValueFactory(cellData -> cellData.getValue().matProperty().get() ? new SimpleStringProperty("X"): new SimpleStringProperty(""));
		colVesp.setCellValueFactory(cellData -> cellData.getValue().vespProperty().get() ? new SimpleStringProperty("X"): new SimpleStringProperty(""));
		colNot.setCellValueFactory(cellData -> cellData.getValue().notProperty().get() ? new SimpleStringProperty("X"): new SimpleStringProperty(""));
	}
	
}


