package application;

import java.io.File;
import java.io.FileWriter;
import java.util.Properties;

import javafx.fxml.FXML;
import javafx.scene.control.ColorPicker;
import javafx.scene.control.TextField;

public class GravaPropertiesController {
	
	@FXML TextField txtLargura;
	@FXML TextField txtAltura;
	@FXML TextField txtLogotipo;
	@FXML TextField txtRazaoSocial;
	@FXML ColorPicker txtCor;
	
	@FXML
	public void gravar() {
		File f = new File(txtLogotipo.getText());
		if(f.isFile()) {
			Properties properties = new Properties();
	        properties.setProperty("Largura", txtLargura.getText());
	        properties.setProperty("Altura", txtAltura.getText());
	        properties.setProperty("Logo", txtLogotipo.getText());
	        properties.setProperty("Cor", "#" + Integer.toHexString(txtCor.getValue().hashCode()));
	        properties.setProperty("RazaoSocial", txtRazaoSocial.getText());
	        
	        try (FileWriter fw = new FileWriter("preferencias.properties");){
				properties.store(fw,"Arquivo de prefer�ncias");
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
	 

}
