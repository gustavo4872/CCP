package application;

import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;

public class TratamentoExcecoesController {
	
	@FXML TextField inputNumero;
	@FXML TextField inputPosicao;
	@FXML TextField inputTamanho;
	
	private int[] vetor;
	
	
	@FXML
	public void instaciaVetor() {
		
		try {
			
			if(Integer.parseInt(inputTamanho.getText()) > 10)
			throw new NumberFormatException("Limite 10");
			vetor = new int[Integer.parseInt(inputTamanho.getText())];
			
		} catch (NumberFormatException e) {
			
			mostraMensagem("Erro no Tamanho do Vetor! " + e.toString(),AlertType.ERROR);
			inputTamanho.requestFocus();
			inputTamanho.selectAll();
			
		} catch (NegativeArraySizeException e) {
			
			mostraMensagem("N�o Pode Ser Negativo! ",AlertType.ERROR);
			inputTamanho.requestFocus();
			inputTamanho.selectAll();
			
		}
		catch (Exception e) {
			
			mostraMensagem("Erro n�o Identificado: " + e.toString(),AlertType.WARNING);
			
		}
		
	}
	
	
	@FXML
	public void inserir() {
		
		try {
			
			int numero = Integer.parseInt(inputNumero.getText());
			int posicao = Integer.parseInt(inputPosicao.getText());
			vetor[posicao] = numero;
			mostraMensagem("N�mero inserido com Sucesso!", AlertType.INFORMATION);
			
		} catch (NumberFormatException e) {
			
			mostraMensagem("Erro de convers�o num�rica!", AlertType.ERROR);
			
		} catch (NegativeArraySizeException e) {
			
			mostraMensagem("Campo posi��o n�o pode ser Negativo!", AlertType.ERROR);
			
		} catch (NullPointerException e) {
			
			mostraMensagem("Vetor n�o instaciado!", AlertType.ERROR);
			
		} catch (ArrayIndexOutOfBoundsException e) {
			
			mostraMensagem("Posi��o n�o existente no vetor! ", AlertType.ERROR);
			
		} catch (Exception e) {
			
			mostraMensagem("Erro n�o identificado: " + e.toString(),AlertType.WARNING);
			
		}
		
	}
	
	
	private void mostraMensagem(String msg, AlertType tipo) {
		
		Alert obj = new  Alert(tipo);
		obj.setHeaderText(null);
		obj.setContentText(msg);
		obj.show();
		
	}
	
}
