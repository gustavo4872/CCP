package application;

import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;

import domain.Aluno;


public class CadastrosAlunosController {
	
	private ArrayList<Aluno> alunos = new ArrayList<Aluno>();
	
	@FXML TextField inputNome;
	@FXML DatePicker inputNascimento;
	@FXML RadioButton setMasculino;
	@FXML RadioButton setFeminino;
	@FXML ComboBox<String> setEstado;
	@FXML CheckBox setMatutino;
	@FXML CheckBox setVespertino;
	@FXML TextField inputFiltro;
	
	@FXML TableView<Aluno> tabela;
	@FXML TableColumn<Aluno, String> colunaNome;
	@FXML TableColumn<Aluno, Number> colunaIdade;
	@FXML TableColumn<Aluno, String> colunaSexo;
	@FXML TableColumn<Aluno, String> colunaMatutino;
	@FXML TableColumn<Aluno, String> colunaVespertino;
	
	@FXML
	public void initialize() {
		setEstado.getItems().addAll("SC","RS","PR");
		
		colunaNome.setCellValueFactory(cellData -> cellData.getValue().nomeProperty());
		colunaIdade.setCellValueFactory(cellData -> cellData.getValue().idadeProperty());
		colunaSexo.setCellValueFactory(cellData -> cellData.getValue().sexoProperty());
		colunaMatutino.setCellValueFactory(cellData -> cellData.getValue().matutinoProperty().get() ? new SimpleStringProperty("X"): new SimpleStringProperty(""));
		colunaVespertino.setCellValueFactory(cellData -> cellData.getValue().vespertinoProperty().get() ? new SimpleStringProperty("X"): new SimpleStringProperty(""));
		
	}
	
	@FXML
	public void cadastrar() {
		
		Aluno obj = new Aluno();
		
		obj.setNome(inputNome.getText());
		obj.setIdade(calculaIdade(inputNascimento.getValue()));
		DateTimeFormatter dateformat = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		obj.setNascimento(dateformat.format(inputNascimento.getValue()));
		obj.setSexo(setMasculino.isSelected() ? "M" : "F");
		obj.setUf(setEstado.getSelectionModel().getSelectedItem());
		obj.setMatutino(setMatutino.isSelected());
		obj.setVespertino(setVespertino.isSelected());
		
		
		alunos.add(obj);
		tabela.setItems(FXCollections.observableArrayList(alunos));
		
	}
	
	private int calculaIdade(LocalDate nascimento) {
		
		LocalDate hoje = LocalDate.now();
		long idade = ChronoUnit.YEARS.between(nascimento, hoje);
		return (int) idade;
		
	}
	
	public void filtrar() {
		
		if(inputFiltro.getText() == "") {
			tabela.setItems(FXCollections.observableArrayList(alunos));
		} else {
			ArrayList<Aluno> aux = new ArrayList<Aluno>();
			for (Aluno obj : alunos) {
				if(obj.getNome().toUpperCase().startsWith(inputFiltro.getText().toUpperCase())) {
					aux.add(obj);
				}
			}
			tabela.setItems(FXCollections.observableArrayList(aux));
		}
		
	}
	
}
